/*
    sim_pag_lru.c
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "sim_paginacion.h"

// Función que inicia las tablas

void iniciar_tablas (ssistema * S)
{
    int i;

    // Páginas a cero
    memset (S->tdp, 0, sizeof(spagina)*S->numpags);

    // Pila LRU vacía
    S->lru = -1;

    // Tiempo LRU(t) a cero
    S->reloj = 0;

    // Lista circular de marcos libres
    for (i=0; i<S->nummarcos-1; i++)
    {
        S->tdm[i].pagina = -1;
        S->tdm[i].sig = i+1;
    }

    S->tdm[i].pagina = -1;  // Ahora i == nummarcos-1
    S->tdm[i].sig = 0;      // Cerrar lista circular
    S->listalibres = i;     // Apuntar al último

    // Lista circular de marcos ocupados vacía
    S->listaocupados = -1;
}

// Funciones que simulan el hardware de la MMU

unsigned sim_mmu (ssistema * S, unsigned dir_virtual, char op)
{
    unsigned dir_fisica;
    int pagina, marco, desplazamiento;

	//Creamos una direccion de memoria a partir de la pagina y el desplazamiento
	pagina = dir_virtual / S->tampag; //Cociente
	desplazamiento = dir_virtual % S->tampag; //Resto

	//Comprobamos que el acceso a la direccion especificada es legal
	if(pagina < 0 || pagina >= S->numpags)
	{
		S->numrefsilegales ++;
		return ~0U; // Devolvemos la direccion F....FF
	}
	
	// Consultamos en la tabla de paginas, para ver si la tabla esta cargada
	if(!S->tdp[pagina].presente) // Si no esta presente
	{
		tratar_fallo_de_pagina(S,dir_virtual);//Tratamos el fallo de pagina
	}
	
	// Ahora ya esta presente
	
	// Ahora tarducimos la direccion virtual a direccion fisica
	marco = S->tdp[pagina].marco; // Calcula la direccion
	dir_fisica = marco * S->tampag + desplazamiento; //Direccion fisica
	
	// Marcamos la pagina como referenciada
	referenciar_pagina(S,pagina,op);
	
	if(S->detallado)
	{
		printf("\t %c %u == P %d (M %d) + %d \n", op,dir_virtual,pagina,marco,desplazamiento);
	
	}
	
    return dir_fisica;
}

void referenciar_pagina (ssistema * S, int pagina, char op)
{

	int desb_reloj = 2147483647;

    if (op=='L')                         // Si es una lectura,
        S->numrefslectura ++;            // contarla
    else if (op=='E')
    {                                    // Si es una escritura,
        S->tdp[pagina].modificada = 1;   // contarla y marcar la
        S->numrefsescritura ++;          // página como modificada
    }
    
    // Guardamos el valor del reloj en el campo timestamp
    S->tdp[pagina].timestamp = S->reloj;
    
    // Si el reloj se desborda lo reiniciamos a 0
    if(S->reloj == desb_reloj) // https://es.wikipedia.org/wiki/Problema_del_a%C3%B1o_2038
    {
    	printf("Desbordamiento del reloj");
    	S->reloj = 0;
    }
    
    // Incrementamos el tamaño del reloj
    S->reloj++;

}

// Funciones que simulan el sistema operativo

void tratar_fallo_de_pagina (ssistema * S, unsigned dir_virtual)
{
    int pagina, victima, marco, ult;
    
    //En primer lugar, calculamos el numero de pagina que provoco el fallo
    S->numfallospag ++; //Incrementamos el contador de fallos de pagina
    pagina = dir_virtual/S->tampag;
    
    if(S->detallado)
    {
        printf ("@ 1⁄2FALLO DE PÁGINA en P %d !\n" , pagina);
    }
    
    //Comprobamos si hay marcos libres
    if(S->listalibres != -1)
    {
        ult = S->listalibres; //Ultimo de la lista
        marco = S->tdm[ult].sig; //Tomamos el siguiente,es decir el primero(lista circular)
        
        if(marco == ult) //Si son el mismo
        {
            S->listalibres = -1; //Solo queda uno libre
        }
        else
        {
            S->tdm[ult].sig = S->tdm[marco].sig; //Si no, puentear
        }
        
        ocupar_marco_libre(S, marco, pagina);
    }
    
    //Si no hay marcos libres, elegimos uno de los que estan ocupados y lo desalojamos
    else
    {
        victima = elegir_pagina_para_reemplazo(S);
        reemplazar_pagina(S,victima,pagina);
    }

}

/*static unsigned aleatorio (unsigned desde,       // <<--- aleatorio
                           unsigned tam)
{
    unsigned n;

    n = desde + (unsigned)(rand()/(RAND_MAX+1.0)*tam);

    if (n>desde+tam-1)      // Estas comprobaciones no
        n = desde+tam-1;    // deberían ser necesarias,
    else if (n<desde)       // pero es mejor no fiarse
        n = desde;          // mucho de las operaciones
                            // en coma flotante
    return n;
}*/

int elegir_pagina_para_reemplazo (ssistema * S)
{
    int marco, victima, pag, t_stamp;
    
	marco = 0;
	pag = S->tdm[marco].pagina;
	t_stamp = S->tdp[pag].timestamp;
    victima = pag;
    
    //Realizamosla busqueda secuencial de la pagina menos utilizada recientemente
    for(marco = 1; marco < S->nummarcos; marco++)
    {
    	pag = S->tdm[marco].pagina; //Accedemos a la pagina
    	
    	// Comparanos los tiempos de las paginas accedidas
    	
    	//Si pag tiene un mayor tiempo de acceso,cambiamos de victima
    	if(S->tdp[pag].timestamp < t_stamp)
    	{
    		t_stamp = S->tdp[pag].timestamp;
    		victima = pag;
    	}
    }

    if (S->detallado)
        printf ("@ Eligiendo (LRU) P%d de M%d para "
                "reemplazarla\n", victima, marco);

    return victima;
}

void reemplazar_pagina (ssistema * S, int victima, int nueva)
{
    int marco;

    marco = S->tdp[victima].marco;

    if (S->tdp[victima].modificada)
    {
        if (S->detallado)
            printf ("@ Volcando P%d modificada a disco para "
                    "reemplazarla\n", victima);

        S->numescrpag ++;
    }

    if (S->detallado)
        printf ("@ Reemplazando víctima P%d por P%d en M%d\n",
                victima, nueva, marco);

    S->tdp[victima].presente = 0;

    S->tdp[nueva].presente = 1;
    S->tdp[nueva].marco = marco;
    S->tdp[nueva].modificada = 0;

    S->tdm[marco].pagina = nueva;
}

void ocupar_marco_libre (ssistema * S, int marco, int pagina)
{
    if (S->detallado)
    {
        printf ("@ Alojando P%d en M%d\n", pagina, marco);
        
        //Ocupamos el marco
        S->tdp[pagina].marco = marco;
        
        //Marcamos la pagina como cargada en un marco(1)
        S->tdp[pagina].presente = 1;
        
        //Marcamos la pagina como no desalojada(0)
        S->tdp[pagina].modificada = 0;
        
        //Indicamosel marco en el que esta cargada la pagina
        S->tdm[marco].pagina = pagina;
        
    }
}

// Funciones que muestran resultados

void mostrar_tabla_de_paginas (ssistema * S)
{
    int p;

    printf ("%10s %10s %10s   %s %s \n",
            "PÁGINA", "Presente", "Marco", "Modificada", "TimeStamp");

    for (p=0; p<S->numpags; p++)
        if (S->tdp[p].presente)
            printf ("%8d   %6d     %8d   %6d %8d\n", p,
                    S->tdp[p].presente, S->tdp[p].marco,
                    S->tdp[p].modificada, S->tdp[p].timestamp);
        else
            printf ("%8d   %6d     %8s   %6s\n", p,
                    S->tdp[p].presente, "-", "-");
}

void mostrar_tabla_de_marcos (ssistema * S)
{
    int p, m;

    printf ("%10s %10s %10s   %s\n",
            "MARCO", "Página", "Presente", "Modificada");

    for (m=0; m<S->nummarcos; m++)
    {
        p = S->tdm[m].pagina;

        if (p==-1)
            printf ("%8d   %8s   %6s     %6s\n", m, "-", "-", "-");
        else if (S->tdp[p].presente)
            printf ("%8d   %8d   %6d     %6d\n", m, p,
                    S->tdp[p].presente, S->tdp[p].modificada);
        else
            printf ("%8d   %8d   %6d     %6s   ¡ERROR!\n", m, p,
                    S->tdp[p].presente, "-");
    }
}

/* Muestra el valor del reloj y los timestamps mmaximos y minimos de las paginas cargadas en memoria */
void mostrar_informe_reemplazo (ssistema * S)
{
	int marco, pagina, minimo, maximo;
	
	marco = 0;
	pagina = S->tdm[marco].pagina;
	minimo = S->tdp[pagina].timestamp;
	maximo = S->tdp[pagina].timestamp;
	
	for(marco = 0; marco < S->nummarcos; marco++)
	{
		pagina = S->tdm[marco].pagina;
		
		//Obtenemos los valores minimos y maximos
		if(S->tdp[pagina].timestamp < minimo)
		{
			minimo = S->tdp[pagina].timestamp;
		}
		if(S->tdp[pagina].timestamp > maximo)
		{
			maximo = S->tdp[pagina].timestamp;
		}
		
	}
	
	printf("Reloj: %d      Minimo: %d       Maximo: %d", S->reloj,minimo,maximo);            
}

